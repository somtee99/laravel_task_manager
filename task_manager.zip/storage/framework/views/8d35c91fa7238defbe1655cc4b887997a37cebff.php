<div class="flex flex-col sm:justify-center items-center pt-2 pb-2 sm:pt-0 bg-gray-100">
    <div class="text-lg w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\Users\okafo\Documents\GitHub\task-manager\resources\views/components/card.blade.php ENDPATH**/ ?>